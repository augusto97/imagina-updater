<?php
/**
 * Gestión de plugins y versiones
 */

if (!defined('ABSPATH')) {
    exit;
}

class Imagina_Updater_Server_Plugin_Manager {

    /**
     * Asegurar que el esquema de BD esté actualizado
     */
    private static function ensure_schema_updated() {
        global $wpdb;
        $table_plugins = $wpdb->prefix . 'imagina_updater_plugins';

        // Verificar si slug_override existe
        $columns = $wpdb->get_results("SHOW COLUMNS FROM $table_plugins LIKE 'slug_override'");
        if (empty($columns)) {
            error_log('IMAGINA UPDATER SERVER: Esquema desactualizado, ejecutando migraciones');
            Imagina_Updater_Server_Database::run_migrations();
        }
    }

    /**
     * Obtener el directorio de uploads para plugins
     */
    public static function get_upload_dir() {
        $upload_dir = wp_upload_dir();
        $plugin_dir = $upload_dir['basedir'] . '/imagina-updater-plugins';

        // Asegurar que el directorio existe con permisos correctos
        if (!file_exists($plugin_dir)) {
            wp_mkdir_p($plugin_dir);
            self::create_protection_files($plugin_dir);
        } elseif (!file_exists($plugin_dir . '/.htaccess')) {
            // Si el directorio existe pero no tiene protección, agregarla
            self::create_protection_files($plugin_dir);
        }

        return $plugin_dir;
    }

    /**
     * Crear archivos de protección en el directorio de uploads
     */
    private static function create_protection_files($dir) {
        // .htaccess para Apache
        $htaccess_content = "# Imagina Updater - Protección de archivos
# Solo permite acceso a través de la API REST de WordPress

Order Deny,Allow
Deny from all

# Bloquear acceso directo
<Files *.zip>
    Deny from all
</Files>";

        @file_put_contents($dir . '/.htaccess', $htaccess_content);

        // web.config para IIS
        $webconfig_content = '<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    <system.webServer>
        <security>
            <requestFiltering>
                <fileExtensions>
                    <add fileExtension=".zip" allowed="false" />
                </fileExtensions>
            </requestFiltering>
        </security>
    </system.webServer>
</configuration>';

        @file_put_contents($dir . '/web.config', $webconfig_content);

        // index.php para prevenir listado de directorios
        @file_put_contents($dir . '/index.php', '<?php // Silence is golden');

        // Archivo de configuración para Nginx (para que el admin lo copie)
        $nginx_content = "# Imagina Updater - Configuración para Nginx
# Agregar dentro del bloque server {}

location ~ ^/wp-content/uploads/imagina-updater-plugins/.*\\.zip$ {
    deny all;
    return 403;
}";

        @file_put_contents($dir . '/nginx.conf.example', $nginx_content);

        imagina_updater_server_log('Archivos de protección creados en: ' . $dir, 'info');
    }

    /**
     * Validar que la versión sea válida
     *
     * No imponemos formato específico (semántico o no), solo verificamos que:
     * - No esté vacía
     * - No contenga caracteres peligrosos
     * - WordPress acepta cualquier formato: 1.0, 1.0.0, 5.5.4.5.1, etc.
     */
    private static function is_valid_version($version) {
        // Solo verificar que no esté vacía y que contenga caracteres permitidos
        // Permitimos números, puntos, guiones y letras (para sufijos como -beta, -rc1, etc.)
        return !empty($version) && preg_match('/^[0-9a-zA-Z\.\-]+$/', $version);
    }

    /**
     * Subir un nuevo plugin o nueva versión
     *
     * @param array $file Archivo ZIP del plugin ($_FILES)
     * @param string|null $changelog Notas de la versión
     * @param bool $force_replace Permitir reemplazar misma versión (para re-inyectar protección, etc.)
     * @return array|WP_Error
     */
    public static function upload_plugin($file, $changelog = null, $force_replace = false) {
        // Validar archivo
        if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            return new WP_Error('invalid_file', __('Archivo no válido', 'imagina-updater-server'));
        }

        if (!file_exists($file['tmp_name'])) {
            return new WP_Error('file_not_found', __('Archivo temporal no encontrado', 'imagina-updater-server'));
        }

        // Validar que sea un ZIP
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

        if (!in_array($mime, array('application/zip', 'application/x-zip-compressed'))) {
            return new WP_Error('invalid_type', __('El archivo debe ser un ZIP', 'imagina-updater-server'));
        }

        // Extraer información del plugin
        $plugin_data = self::extract_plugin_info($file['tmp_name']);

        if (is_wp_error($plugin_data)) {
            return $plugin_data;
        }

        // Validar versión
        if (!self::is_valid_version($plugin_data['version'])) {
            return new WP_Error('invalid_version', __('Versión inválida. La versión no puede estar vacía y solo puede contener números, puntos, guiones y letras.', 'imagina-updater-server'));
        }

        // Mover archivo a directorio seguro
        $upload_dir = self::get_upload_dir();
        $filename = sanitize_file_name($plugin_data['slug'] . '-' . $plugin_data['version'] . '.zip');
        $file_path = $upload_dir . '/' . $filename;

        // Usar wp_handle_upload para mover el archivo de forma segura
        $upload_overrides = array(
            'test_form' => false,
            'unique_filename_callback' => function ($dir, $name, $ext) use ($filename) {
                return $filename;
            },
        );

        // Mover archivo usando la función de WordPress
        global $wp_filesystem;
        if (empty($wp_filesystem)) {
            require_once ABSPATH . '/wp-admin/includes/file.php';
            WP_Filesystem();
        }

        // Copiar el archivo temporal al destino
        if (!copy($file['tmp_name'], $file_path)) {
            $error_msg = error_get_last();
            return new WP_Error('upload_failed', __('Error al mover el archivo', 'imagina-updater-server') . ': ' . ($error_msg['message'] ?? 'Desconocido'));
        }

        // Hook para que extensiones puedan procesar el archivo antes de guardar en BD
        // Ej: inyectar SDK de licencias
        do_action('imagina_updater_after_move_plugin_file', $file_path, $plugin_data);

        // Calcular checksum
        $checksum = hash_file('sha256', $file_path);
        $file_size = filesize($file_path);

        // Asegurar que el esquema esté actualizado
        self::ensure_schema_updated();

        // Guardar en base de datos
        global $wpdb;
        $table_plugins = $wpdb->prefix . 'imagina_updater_plugins';
        $table_versions = $wpdb->prefix . 'imagina_updater_versions';

        // Verificar si el plugin ya existe
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_plugins WHERE slug = %s",
            $plugin_data['slug']
        ));

        // Usar transacciones para garantizar consistencia
        $wpdb->query('START TRANSACTION');

        try {
            if ($existing) {
                // Verificar versión: si force_replace está activo, permitir misma versión
                $is_same_version = version_compare($plugin_data['version'], $existing->current_version, '=');
                $is_older_version = version_compare($plugin_data['version'], $existing->current_version, '<');

                if ($is_older_version) {
                    wp_delete_file($file_path);
                    throw new Exception(__('La versión debe ser igual o mayor a la actual', 'imagina-updater-server'));
                }

                if ($is_same_version && !$force_replace) {
                    wp_delete_file($file_path);
                    throw new Exception(__('Esta versión ya existe. Activa "Permitir reemplazar misma versión" si deseas resubir el plugin.', 'imagina-updater-server'));
                }

                // Si es misma versión con force_replace, eliminar archivo anterior (no guardar en historial)
                if ($is_same_version && $force_replace) {
                    if (file_exists($existing->file_path) && $existing->file_path !== $file_path) {
                        wp_delete_file($existing->file_path);
                    }
                    imagina_updater_server_log(sprintf('Reemplazando misma versión del plugin: %s v%s', $plugin_data['name'], $plugin_data['version']), 'info');
                } else {
                    // Solo guardar versión anterior en historial si es una versión diferente
                    $result = $wpdb->insert(
                        $table_versions,
                        array(
                            'plugin_id' => $existing->id,
                            'version' => $existing->current_version,
                            'file_path' => $existing->file_path,
                            'file_size' => $existing->file_size,
                            'checksum' => $existing->checksum,
                            'uploaded_at' => $existing->uploaded_at
                        ),
                        array('%d', '%s', '%s', '%d', '%s', '%s')
                    );

                    if ($result === false) {
                        throw new Exception(__('Error al guardar historial de versión', 'imagina-updater-server'));
                    }
                }

                // Actualizar plugin con nueva versión
                $result = $wpdb->update(
                    $table_plugins,
                    array(
                        'current_version' => $plugin_data['version'],
                        'file_path' => $file_path,
                        'file_size' => $file_size,
                        'checksum' => $checksum,
                        'uploaded_at' => current_time('mysql'),
                        'name' => $plugin_data['name'],
                        'description' => $plugin_data['description'],
                        'author' => $plugin_data['author'],
                        'homepage' => $plugin_data['homepage']
                    ),
                    array('id' => $existing->id),
                    array('%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s'),
                    array('%d')
                );

                if ($result === false) {
                    throw new Exception(__('Error al actualizar plugin', 'imagina-updater-server'));
                }

                $plugin_id = $existing->id;
            } else {
                // Crear nuevo plugin
                $result = $wpdb->insert(
                    $table_plugins,
                    array(
                        'slug' => $plugin_data['slug'],
                        'slug_override' => null,
                        'name' => $plugin_data['name'],
                        'description' => $plugin_data['description'],
                        'author' => $plugin_data['author'],
                        'homepage' => $plugin_data['homepage'],
                        'current_version' => $plugin_data['version'],
                        'file_path' => $file_path,
                        'file_size' => $file_size,
                        'checksum' => $checksum,
                        'uploaded_at' => current_time('mysql')
                    ),
                    array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s')
                );

                if ($result === false) {
                    throw new Exception(__('Error al crear plugin', 'imagina-updater-server'));
                }

                $plugin_id = $wpdb->insert_id;
            }

            // Guardar changelog si se proporcionó
            if (!empty($changelog)) {
                $result = $wpdb->insert(
                    $table_versions,
                    array(
                        'plugin_id' => $plugin_id,
                        'version' => $plugin_data['version'],
                        'file_path' => $file_path,
                        'file_size' => $file_size,
                        'checksum' => $checksum,
                        'changelog' => sanitize_textarea_field($changelog),
                        'uploaded_at' => current_time('mysql')
                    ),
                    array('%d', '%s', '%s', '%d', '%s', '%s', '%s')
                );

                if ($result === false) {
                    throw new Exception(__('Error al guardar changelog', 'imagina-updater-server'));
                }
            }

            // Commit de la transacción
            $wpdb->query('COMMIT');

            $result_data = array(
                'id' => $plugin_id,
                'slug' => $plugin_data['slug'],
                'name' => $plugin_data['name'],
                'version' => $plugin_data['version']
            );

            // Hook para que extensiones puedan ejecutar acciones después de subir el plugin
            do_action('imagina_updater_after_upload_plugin', $result_data, $file_path);

            return $result_data;

        } catch (Exception $e) {
            // Rollback en caso de error
            $wpdb->query('ROLLBACK');

            // Limpiar archivo si existe
            if (file_exists($file_path)) {
                wp_delete_file($file_path);
            }

            return new WP_Error('transaction_failed', $e->getMessage());
        }
    }

    /**
     * Extraer información del plugin desde el ZIP
     *
     * @param string $zip_path Ruta al archivo ZIP
     * @return array|WP_Error
     */
    private static function extract_plugin_info($zip_path) {
        $zip = new ZipArchive();

        if ($zip->open($zip_path) !== true) {
            return new WP_Error('zip_error', __('No se pudo abrir el archivo ZIP', 'imagina-updater-server'));
        }

        // Buscar archivo principal del plugin y extraer carpeta raíz
        $plugin_file = null;
        $plugin_folder = null;

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $filename = $zip->getNameIndex($i);

            // Buscar archivos .php en el raíz o dentro de una carpeta (primer nivel)
            // Acepta: plugin.php o carpeta/plugin.php
            if (preg_match('/^([^\/]+\.php|[^\/]+\/[^\/]+\.php)$/', $filename)) {
                $content = $zip->getFromIndex($i);

                // Verificar si tiene los headers de plugin
                if (preg_match('/Plugin Name:/i', $content)) {
                    $plugin_file = $content;

                    // Extraer nombre de la carpeta desde la ruta del archivo
                    // Si es "carpeta/archivo.php", extraer "carpeta"
                    // Si es "archivo.php", usar el nombre del archivo sin extensión
                    if (strpos($filename, '/') !== false) {
                        $plugin_folder = substr($filename, 0, strpos($filename, '/'));
                    } else {
                        // Plugin en raíz del ZIP (sin carpeta)
                        $plugin_folder = basename($filename, '.php');
                    }

                    break;
                }
            }
        }

        $zip->close();

        if (!$plugin_file || !$plugin_folder) {
            return new WP_Error('no_plugin_header', __('No se encontró archivo de plugin válido en el ZIP', 'imagina-updater-server'));
        }

        // Extraer información usando función de WordPress
        require_once ABSPATH . 'wp-admin/includes/plugin.php';

        $plugin_data = array();

        // Extraer headers del plugin
        if (preg_match('/Plugin Name:\s*(.+)/i', $plugin_file, $matches)) {
            $plugin_data['name'] = trim($matches[1]);
        }

        if (preg_match('/Version:\s*(.+)/i', $plugin_file, $matches)) {
            $plugin_data['version'] = trim($matches[1]);
        }

        if (preg_match('/Description:\s*(.+)/i', $plugin_file, $matches)) {
            $plugin_data['description'] = trim($matches[1]);
        }

        if (preg_match('/Author:\s*(.+)/i', $plugin_file, $matches)) {
            $plugin_data['author'] = trim($matches[1]);
        }

        if (preg_match('/Plugin URI:\s*(.+)/i', $plugin_file, $matches)) {
            $plugin_data['homepage'] = trim($matches[1]);
        }

        // Validar datos mínimos
        if (empty($plugin_data['name']) || empty($plugin_data['version'])) {
            return new WP_Error('invalid_plugin', __('El plugin no tiene nombre o versión definidos', 'imagina-updater-server'));
        }

        // USAR EL NOMBRE DE LA CARPETA COMO SLUG (no el nombre del plugin)
        // Esto asegura que el slug coincida con la estructura real del plugin
        $plugin_data['slug'] = sanitize_file_name($plugin_folder);

        return $plugin_data;
    }

    /**
     * Obtener todos los plugins
     *
     * @return array
     */
    public static function get_all_plugins() {
        self::ensure_schema_updated();

        global $wpdb;
        $table = $wpdb->prefix . 'imagina_updater_plugins';

        return $wpdb->get_results("SELECT * FROM $table ORDER BY name ASC");
    }

    /**
     * Obtener un plugin por slug (verifica tanto slug como slug_override)
     *
     * @param string $slug Slug del plugin
     * @return object|null
     */
    public static function get_plugin_by_slug($slug) {
        self::ensure_schema_updated();

        global $wpdb;
        $table = $wpdb->prefix . 'imagina_updater_plugins';

        // Primero buscar por slug_override, luego por slug normal
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE slug_override = %s OR (slug_override IS NULL AND slug = %s) LIMIT 1",
            $slug,
            $slug
        ));
    }

    /**
     * Actualizar el slug personalizado de un plugin
     *
     * @param int $plugin_id ID del plugin
     * @param string|null $new_slug Nuevo slug (null para usar el auto-generado)
     * @return bool|WP_Error
     */
    public static function update_plugin_slug($plugin_id, $new_slug) {
        self::ensure_schema_updated();

        global $wpdb;
        $table_plugins = $wpdb->prefix . 'imagina_updater_plugins';

        // Validar que el plugin existe
        $plugin = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_plugins WHERE id = %d",
            $plugin_id
        ));

        if (!$plugin) {
            error_log('IMAGINA UPDATER SERVER: Plugin no encontrado con ID: ' . $plugin_id);
            return new WP_Error('not_found', __('Plugin no encontrado', 'imagina-updater-server'));
        }

        // Si el nuevo slug es igual al slug auto-generado, usar NULL
        if ($new_slug === $plugin->slug) {
            $new_slug = null;
        }

        // Si se proporciona un slug, validarlo
        if ($new_slug !== null && $new_slug !== '') {
            // Sanitizar
            $new_slug = sanitize_title($new_slug);

            if (empty($new_slug)) {
                error_log('IMAGINA UPDATER SERVER: Slug inválido después de sanitizar');
                return new WP_Error('invalid_slug', __('Slug inválido', 'imagina-updater-server'));
            }

            // Verificar que no exista otro plugin con ese slug
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $table_plugins
                WHERE id != %d AND (slug = %s OR slug_override = %s)",
                $plugin_id,
                $new_slug,
                $new_slug
            ));

            if ($exists > 0) {
                error_log('IMAGINA UPDATER SERVER: Ya existe un plugin con slug: ' . $new_slug);
                return new WP_Error('slug_exists', __('Ya existe un plugin con ese slug', 'imagina-updater-server'));
            }
        } else {
            // Si está vacío, usar NULL para restablecer al auto-generado
            $new_slug = null;
        }

        error_log('IMAGINA UPDATER SERVER: Actualizando slug_override a: ' . var_export($new_slug, true) . ' para plugin ID: ' . $plugin_id);

        // Actualizar slug_override
        $result = $wpdb->update(
            $table_plugins,
            array('slug_override' => $new_slug),
            array('id' => $plugin_id),
            array('%s'),
            array('%d')
        );

        if ($result === false) {
            error_log('IMAGINA UPDATER SERVER: Error de BD al actualizar slug. Error: ' . $wpdb->last_error);
            return new WP_Error('update_failed', __('Error al actualizar el slug en la base de datos: ', 'imagina-updater-server') . $wpdb->last_error);
        }

        error_log('IMAGINA UPDATER SERVER: Slug actualizado exitosamente. Filas afectadas: ' . $result);

        return true;
    }

    /**
     * Obtener historial de versiones de un plugin
     *
     * @param int $plugin_id ID del plugin
     * @return array
     */
    public static function get_version_history($plugin_id) {
        global $wpdb;

        $table = $wpdb->prefix . 'imagina_updater_versions';

        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE plugin_id = %d ORDER BY uploaded_at DESC",
            $plugin_id
        ));
    }

    /**
     * Eliminar un plugin y todas sus versiones
     *
     * @param int $plugin_id ID del plugin
     * @return bool|WP_Error
     */
    public static function delete_plugin($plugin_id) {
        global $wpdb;

        $table_plugins = $wpdb->prefix . 'imagina_updater_plugins';
        $table_versions = $wpdb->prefix . 'imagina_updater_versions';

        // Obtener plugin
        $plugin = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_plugins WHERE id = %d",
            $plugin_id
        ));

        if (!$plugin) {
            return new WP_Error('not_found', __('Plugin no encontrado', 'imagina-updater-server'));
        }

        // Eliminar archivo actual
        if (file_exists($plugin->file_path)) {
            wp_delete_file($plugin->file_path);
        }

        // Obtener y eliminar archivos de versiones antiguas
        $versions = self::get_version_history($plugin_id);
        foreach ($versions as $version) {
            if (file_exists($version->file_path)) {
                wp_delete_file($version->file_path);
            }
        }

        // Eliminar de base de datos
        $wpdb->delete($table_versions, array('plugin_id' => $plugin_id), array('%d'));
        $wpdb->delete($table_plugins, array('id' => $plugin_id), array('%d'));

        return true;
    }

    /**
     * Registrar descarga de plugin
     *
     * @param int $api_key_id ID de la API key
     * @param int $plugin_id ID del plugin
     * @param string $version Versión descargada
     */
    public static function log_download($api_key_id, $plugin_id, $version) {
        global $wpdb;

        $table = $wpdb->prefix . 'imagina_updater_downloads';

        $wpdb->insert(
            $table,
            array(
                'api_key_id' => $api_key_id,
                'plugin_id' => $plugin_id,
                'version' => $version,
                'ip_address' => self::get_client_ip(),
                'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? substr($_SERVER['HTTP_USER_AGENT'], 0, 500) : '',
                'downloaded_at' => current_time('mysql')
            ),
            array('%d', '%d', '%s', '%s', '%s', '%s')
        );
    }

    /**
     * Obtener IP del cliente de forma segura
     */
    private static function get_client_ip() {
        $ip = '';

        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif (isset($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (isset($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }

        // Validar y sanitizar IP
        $ip = filter_var($ip, FILTER_VALIDATE_IP);

        return $ip ? $ip : '';
    }
}
